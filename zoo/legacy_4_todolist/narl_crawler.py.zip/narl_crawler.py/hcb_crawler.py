import selenium
from selenium.webdriver import chrome
import ddddocr
import matplotlib.pyplot as plt

class CrawlerEMIC:

    account_path = 'account.txt'
    captcha_path = 'captcha.png'

    def __init__(self, debug=False):
        self.debug = debug
        self.online = True
        # read the account and password from the file
        with open(self.account_path, 'r') as f:
            self.account = f.readline().strip()
            self.password = f.readline().strip()
        # check the account and password
        if self.account == '' or self.password == '':
            raise Exception('Please input the account and password in the file: ' + self.account_path)
        
        self.ocr = ddddocr.DdddOcr()
        self.driver = chrome.webdriver.WebDriver()

    def login(self):
        if self.driver:
            # open the login page
            self.driver.get('https://netbank.hncb.com.tw/netbank/servlet/TrxDispatcher?trx=com.lb.wibc.trx.Login&state=prompt&Recognition=private')

            captcha = self.driver.find_element('xpath', '//*[@id="code_Cap"]')
            # save the captcha image
            captcha.screenshot(self.captcha_path)

            # input the account and password
            tb_account = self.driver.find_element('xpath', '//*[@id="USERID"]')
            tb_account.send_keys(self.account)

            # tb_password = self.driver.find_element('xpath', '//*[@id="inputPassword"]')
            # tb_password.send_keys(self.password)

            # use ddddocr to recognize the captcha image
            ocr = ddddocr.DdddOcr()
            with open(self.captcha_path, 'rb') as f:
                img_bytes = f.read()
            res = ocr.classification(img_bytes)

            # input the recognized text
            tb_captcha = self.driver.find_element('xpath', '//*[@id="TrxCaptchaKey"]')
            tb_captcha.send_keys(res)

            # click the login button
            #btn_login = self.driver.find_element('xpath', '//*[@id="LoginForm"]/div[5]/div[1]/button')

            # if  not self.debug:
            #     btn_login.click()

            if self.debug:
                # open the captcha image
                img = plt.imread(self.captcha_path)
                # add the recognized text to the image
                plt.text(0, 0, res, fontsize=20, color='red')
                plt.imshow(img)
                plt.show()
    
if __name__ == '__main__':
    crawler = CrawlerEMIC(debug=True)
    crawler.login()